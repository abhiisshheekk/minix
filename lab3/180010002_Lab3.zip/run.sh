cp -f schedule.c /usr/src/minix/servers/sched/schedule.c
cd /usr/src/
make build MKUPDATE=yes >log.txt 2>log.txt